<?php

$firstName = "Zlaten";
$lastName = "Mamin";
$age = "32";

$fullName = $firstName.' '.$lastName;

echo "My name is ".$fullName." and I am ".$age." years old";

?>