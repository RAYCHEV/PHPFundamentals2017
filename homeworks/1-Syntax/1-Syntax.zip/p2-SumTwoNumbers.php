<?php

$firstNumber = 1.456793876;
$secondNumber = 19;

$sum = $firstNumber + $secondNumber;

echo round($sum, 2);