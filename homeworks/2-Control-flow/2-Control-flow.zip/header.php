<!doctype html>
<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <style>

        table, td, tr, thead, tfoot {
            border: solid 1px black;
            border-collapse: collapse;
            padding: 5px;

        }
        thead {

            font-weight: bold;
        }

        .bold {
            font-weight: bold;
            font-family: fantasy;
        }


    </style>
</head>
<body>